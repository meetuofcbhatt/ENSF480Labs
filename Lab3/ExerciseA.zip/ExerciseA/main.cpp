#include <iostream>
#include "GraphicsWorld.h"

int main() {
    GraphicsWorld::run();
    return 0;
}
