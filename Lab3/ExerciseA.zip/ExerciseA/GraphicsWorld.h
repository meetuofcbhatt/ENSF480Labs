/*
* File Name: graphicsWorld.h
* Assignment: Lab 1 Exercise B
* Lab Section: B02
* Completed by: Tomas Kmet and Meet Bhett
* Submission Date: Oct 2, 2023
*/

#ifndef EXERCISEA_GRAPHICSWORLD_H
#define EXERCISEA_GRAPHICSWORLD_H


#include "Point.h"
class GraphicsWorld{
public:
    static void run();
};

#endif //EXERCISEA_GRAPHICSWORLD_H
